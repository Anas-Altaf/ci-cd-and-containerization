// Import statements (this part is typically handled automatically, but including it for clarity)
import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS

// Send request to the 'ListUsers' API and get response
response = WS.sendRequestAndVerify(findTestObject('UserRestService/ListUsers'))

// Verify specific data in the API response
WS.verifyElementPropertyValue(response, 'data[1].first_name', 'Lindsay')
WS.verifyElementPropertyValue(response, 'data[2].id', '9')
